package com.babacode.walletexpensetracker.data.model

data class DateForQuery(
    val startDate: Long,
    val endDate: Long
)